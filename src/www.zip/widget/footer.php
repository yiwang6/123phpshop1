<?php 
/**
 * 123PHPSHOP
 * ============================================================================
 * 版权所有 2015 上海序程信息科技有限公司，并保留所有权利。
 * 网站地址: http://www.123PHPSHOP.com；
 * ----------------------------------------------------------------------------
 * 这是一个免费的软件。您可以在商业目的和非商业目的地前提下对程序除本声明之外的
 * 代码进行修改和使用；您可以对程序代码进行再发布，但一定请保留
 * 本声明和上海序程信息科技有限公司的联系方式！本软件中使用到的第三方代码版权属
 * 于原公司所有。上海序程信息科技有限公司拥有对本声明和123PHPSHOP软件使用的最终
 * 解释权！
 * ============================================================================
 *  作者:	123PHPSHOP团队
 *  手机:	13391334121
 *  邮箱:	service@123phpshop.com
 */
 ?><?php 

 
?>
<?php
$maxRows_friend_links = 10;
$pageNum_friend_links = 0;
if (isset($_GET['pageNum_friend_links'])) {
  $pageNum_friend_links = $_GET['pageNum_friend_links'];
}
$startRow_friend_links = $pageNum_friend_links * $maxRows_friend_links;

mysql_select_db($database_localhost, $localhost);
$query_friend_links = "SELECT * FROM friend_links WHERE is_delete = 0 order by sort desc";
$query_limit_friend_links = sprintf("%s LIMIT %d, %d", $query_friend_links, $startRow_friend_links, $maxRows_friend_links);
$friend_links = mysql_query($query_limit_friend_links, $localhost) or die(mysql_error());
$row_friend_links = mysql_fetch_assoc($friend_links);

if (isset($_GET['totalRows_friend_links'])) {
  $totalRows_friend_links = $_GET['totalRows_friend_links'];
} else {
  $all_friend_links = mysql_query($query_friend_links);
  $totalRows_friend_links = mysql_num_rows($all_friend_links);
}
$totalPages_friend_links = ceil($totalRows_friend_links/$maxRows_friend_links)-1;
?>
<style type="text/css">
<!--
.footer_link_title {font-size: 16px;margin:0 auto;}
.footer_top_big {font-size: 20px; font-weight: bold; margin:0 auto; }
-->
</style>
<br />
<div style="width:100%;background-color:#F5F5F5;text-align:cetner;">
<table width="1210" height="94" border="0" align="center" style="margin:0 auto;" >
  <tr>
    <td><div align="center" class="footer_top_big">
      <div align="left">轻松购物</div>
    </div></td>
    <td><div align="center" class="footer_top_big">
      <div align="left">极速配送</div>
    </div></td>
    <td><div align="left" class="footer_top_big">
      <div align="left">正品行货</div>
    </div></td>
    <td><div align="left" class="footer_top_big">天天低价</div></td>
  </tr>
</table>
</div>
<table width="1210" height="168" border="0" align="center" style="margin:0 auto;">
  <tr style="color:#666666;">
    <td width="199" height="36" align="center"><div align="center" width="199" class="footer_link_title">
      <div align="left"><span class="footer_link_title ">购物指南</span></div>
    </div></td>
    <td width="199" height="36"><div align="center" width="199" class="footer_link_title">
      <div align="left"><span class="footer_link_title  ">配送方式</span></div>
    </div></td>
    <td width="199" height="36"><div align="center" width="199" class="footer_link_title">
      <div align="left"><span class="footer_link_title  ">支付方式</span></div>
    </div></td>
    <td width="199" height="36"><div align="center" width="199" class="footer_link_title">
      <div align="left"><span class="footer_link_title  ">售后服务</span></div>
    </div></td>
    <td width="199" height="36"><div align="center"width="199" class="footer_link_title">
      <div align="left"><span class="footer_link_title  ">特色服务</span></div>
    </div></td>
  </tr>
  <tr style="font-family:SimSun;font-size:12px;">
    <td height="120" valign="top">
      <div align="center">
        <table width="199" border="0" align="left" >
          <tr>
            <td>购物流程</td>
          </tr>
          <tr>
            <td>会员介绍</td>
          </tr>
          <tr>
            <td>生活旅行/团购</td>
          </tr>
          <tr>
            <td>常见问题</td>
          </tr>
          <tr>
            <td>大家电</td>
          </tr>
          <tr>
            <td>联系客服</td>
          </tr>
        </table>
    </div></td>
    <td height="120" valign="top">
      <div align="center">
        <table width="199" border="0" align="left">
          <tr>
            <td>上门自提</td>
          </tr>
          <tr>
            <td>211限时达</td>
          </tr>
          <tr>
            <td>配送服务查询</td>
          </tr>
          <tr>
            <td>配送费收取标准</td>
          </tr>
          <tr>
            <td>海外配送</td>
          </tr>
          <tr>
            <td>&nbsp;</td>
          </tr>
        </table>
    </div></td>
    <td height="120" valign="top">
      
      <div align="center">
        <table width="199" border="0" align="left">
          <tr>
            <td>货到付款</td>
          </tr>
          <tr>
            <td>在线支付</td>
          </tr>
          <tr>
            <td>分期付款</td>
          </tr>
          <tr>
            <td>邮局汇款</td>
          </tr>
          <tr>
            <td>公司转账</td>
          </tr>
          <tr>
            <td>&nbsp;</td>
          </tr>
        </table>
    </div></td>
    <td height="120" valign="top">
      <div align="center">
        <table width="199" border="0" align="left">
          <tr>
            <td>售后政策</td>
          </tr>
          <tr>
            <td>价格保护</td>
          </tr>
          <tr>
            <td>退款说明</td>
          </tr>
          <tr>
            <td>返修/退换货</td>
          </tr>
          <tr>
            <td>取消订单</td>
          </tr>
          <tr>
            <td>&nbsp;</td>
          </tr>
        </table>
    </div></td>
    <td height="120" valign="top"><div align="center">
      <table width="199" border="0" align="left">
        <tr>
          <td>夺宝岛</td>
          </tr>
        <tr>
          <td>DIY装机</td>
          </tr>
        <tr>
          <td>延保服务</td>
          </tr>
        <tr>
          <td>E卡</td>
          </tr>
        <tr>
          <td>通信</td>
          </tr>
        <tr>
          <td>&nbsp;</td>
          </tr>
      </table>
    </div></td>
  </tr>
</table>
<hr width="1210"  style="border:none;border-bottom:1px solid #E5E5E5; overflow:hidden;margin:20px auto;" />

 <table width="1210" border="0" align="center" style="margin:0 auto;">
 <tr>
       <td class="footer_link_title">合作站点</td>
 </tr>
   <tr>
    <?php do { ?>
      <td height="25"><a style="text-decoration:none;color:#000000;" href="<?php echo $row_friend_links['link_url']; ?>" target="_blank"><?php echo $row_friend_links['link_text']; ?></a></td>
      <?php } while ($row_friend_links = mysql_fetch_assoc($friend_links)); ?></tr>
</table>

<table width="1210" height="72" border="0" align="center" style="margin:0 auto;font-family:SimSun;font-size:12px;">
   <tr>
    <td height=""><div align="center">本系统由上海序程信息科技有限公司提供技术支持 Powered By 123phpshop.com</div></td>
  </tr>
</table>
<?php require($_SERVER['DOCUMENT_ROOT'] . "/stat/stats.php"); ?>