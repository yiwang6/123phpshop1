<?php 
/**
 * 123PHPSHOP
 * ============================================================================
 * 版权所有 2015 上海序程信息科技有限公司，并保留所有权利。
 * 网站地址: http://www.123PHPSHOP.com；
 * ----------------------------------------------------------------------------
 * 这是一个免费的软件。您可以在商业目的和非商业目的地前提下对程序除本声明之外的
 * 代码进行修改和使用；您可以对程序代码进行再发布，但一定请保留
 * 本声明和上海序程信息科技有限公司的联系方式！本软件中使用到的第三方代码版权属
 * 于原公司所有。上海序程信息科技有限公司拥有对本声明和123PHPSHOP软件使用的最终
 * 解释权！
 * ============================================================================
 *  作者:	123PHPSHOP团队
 *  手机:	13391334121
 *  邮箱:	service@123phpshop.com
 */
 ?><?php
/**
* PHPMailer language file: refer to English translation for definitive list
* Chinese Version
* By LiuXin: www.80x86.cn/blog/
*/

$PHPMAILER_LANG['authenticate'] = 'SMTP 错误：身份验证失败。';
$PHPMAILER_LANG['connect_host'] = 'SMTP 错误: 不能连接SMTP主机。';
$PHPMAILER_LANG['data_not_accepted'] = 'SMTP 错误: 数据不可接受。';
//$PHPMAILER_LANG['empty_message']        = 'Message body empty';
$PHPMAILER_LANG['encoding'] = '未知编码：';
$PHPMAILER_LANG['execute'] = '不能执行: ';
$PHPMAILER_LANG['file_access'] = '不能访问文件：';
$PHPMAILER_LANG['file_open'] = '文件错误：不能打开文件：';
$PHPMAILER_LANG['from_failed'] = '下面的发送地址邮件发送失败了： ';
$PHPMAILER_LANG['instantiate'] = '不能实现mail方法。';
//$PHPMAILER_LANG['invalid_email']        = 'Not sending, email address is invalid: ';
$PHPMAILER_LANG['mailer_not_supported'] = ' 您所选择的发送邮件的方法并不支持。';
$PHPMAILER_LANG['provide_address'] = '您必须提供至少一个 收信人的email地址。';
$PHPMAILER_LANG['recipients_failed'] = 'SMTP 错误： 下面的 收件人失败了： ';
//$PHPMAILER_LANG['signing']              = 'Signing Error: ';
//$PHPMAILER_LANG['smtp_connect_failed']  = 'SMTP Connect() failed.';
//$PHPMAILER_LANG['smtp_error']           = 'SMTP server error: ';
//$PHPMAILER_LANG['variable_set']         = 'Cannot set or reset variable: ';
?>